from setuptools import setup, find_packages

setup(
    name="menu_app_func",
    version="0.1",
    packages=find_packages(),
    install_requires=[],
    include_package_data=True,
)